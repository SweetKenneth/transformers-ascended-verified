/**
 * CMPSBL® — Artifact Verification Script
 * ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 * Run this to verify your artifact's capability integrity.
 *
 *   npx ts-node RUN_VERIFICATION.ts
 *
 * Fingerprint: fa43ab505192a743
 * Generated:   2026-04-11T04:11:06.519Z
 *
 * © CMPSBL® — All rights reserved.
 */

import { runAllProbes } from '@cmpsbl/runtime/verify';

const ARTIFACT_FINGERPRINT = 'fa43ab505192a743';

const EXPECTED_PRIMITIVES = [
  'CORE',
  'SYSTEM',
  'MEMORY',
  'NERVE',
  'ENCODE',
  'RELAY',
  'IDENTITY',
  'BRAIN',
  'DREAM',
  'DEFENSE',
  'REFLEX',
  'EVOLUTION',
  'SANDBOX',
  'DECODE',
  'APEX',
  'INTENT',
] as const;

async function verify() {
  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log('  CMPSBL® Artifact Verification');
  console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
  console.log(`Fingerprint: ${ARTIFACT_FINGERPRINT}`);
  console.log(`Primitives:  ${EXPECTED_PRIMITIVES.length} expected\n`);

  const results = await runAllProbes({
    expected: EXPECTED_PRIMITIVES,
    fingerprint: ARTIFACT_FINGERPRINT,
  });

  // ━━━ Identity binding: execution ↔ identity ↔ proof ━━━
  if (results.fingerprint !== ARTIFACT_FINGERPRINT) {
    console.error('\n🚨 FINGERPRINT MISMATCH — artifact integrity compromised');
    console.error(`   Expected: ${ARTIFACT_FINGERPRINT}`);
    console.error(`   Received: ${results.fingerprint}`);
    throw new Error('Fingerprint mismatch — artifact integrity compromised');
  }

  console.log('\n✓ Fingerprint verified: identity bound to execution\n');

  // ━━━ Fail-closed: every expected primitive must have a probe ━━━
  const probeNames = new Set((results.probes ?? []).map((r: { primitiveName: string }) => r.primitiveName));
  const missing = EXPECTED_PRIMITIVES.filter(p => !probeNames.has(p));
  if (missing.length > 0) {
    console.error(`\n🚨 VERIFICATION INCOMPLETE — missing probes for:`);
    missing.forEach(m => console.error(`   ✗ ${m}`));
    throw new Error(`Verification incomplete — missing probes for: ${missing.join(', ')}`);
  }
  // ━━━ Tamper signal: detect injected/rogue primitives ━━━
  const expectedSet = new Set(EXPECTED_PRIMITIVES as readonly string[]);
  const unexpected = (results.probes ?? [])
    .map((r: { primitiveName: string }) => r.primitiveName)
    .filter((p: string) => !expectedSet.has(p));
  if (unexpected.length > 0) {
    console.warn(`\n🚨 UNEXPECTED PROBES DETECTED:`);
    unexpected.forEach((u: string) => console.warn(`   ⚠ ${u}`));
    console.warn('  This may indicate injected primitives or rogue wrappers.\n');
  }

  // ━━━ Probe delta context: instant interpretability ━━━
  console.warn(`\n🔍 Probe Delta:`);
  console.warn(`   Expected: ${EXPECTED_PRIMITIVES.length}`);
  console.warn(`   Observed: ${probeNames.size}`);
  console.warn(`   Extra:    ${unexpected.length}`);

  // ━━━ Single-line status header ━━━
  const verified = results.verified ?? 0;
  const total = EXPECTED_PRIMITIVES.length;
  console.log(`\nSTATUS: ${verified === total ? 'FULLY VERIFIED' : 'PARTIALLY VERIFIED'} | ${verified}/${total}`);

  console.log('━━━ Results ━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
  console.log(JSON.stringify(results, null, 2));



  console.log(`\n✓ ${verified}/${total} primitives behaviorally verified`);
  console.log(`✓ ${total}/${total} primitives accounted for (fail-closed)`);

  if (verified < total) {
    console.log(`⚠ ${total - verified} primitives pending full behavioral verification`);
    console.log('  Run with runtime integration to complete verification.');
  }

  console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
}

verify().catch(console.error);
